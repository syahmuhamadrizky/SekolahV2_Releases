# 🏫 Dapoy Schools (v1.5.4)

**Dapoy Schools** adalah platform sistem informasi dan manajemen operasional sekolah generasi baru. Dibangun dengan desain antarmuka *Glassmorphism* yang modern, dukungan Mode Gelap (Dark Mode), dan performa kilat, aplikasi ini dirancang khusus untuk memenuhi segala kebutuhan digitalisasi sekolah masa kini—mulai dari penerimaan siswa baru, absensi, hingga publikasi mading digital.

---

## ✨ Fitur Unggulan

Dapoy Schools hadir dengan segudang fitur *All-in-One* yang dibagi menjadi beberapa modul utama:

### 1. 🛡️ Sistem Lisensi & Keamanan Terpusat
- **Proteksi Hardware (HWID):** Lisensi aplikasi terkunci pada spesifikasi perangkat (atau otomatis di-bypass aman untuk Shared Hosting/cPanel) mencegah pembajakan.
- **Sistem *Free Trial*:** Pengalaman uji coba gratis selama **5 Hari** secara otomatis pada instalasi pertama sebelum aplikasi terkunci.
- **Integrasi Dapoy Hub:** Sinkronisasi langsung dengan `hub.dapoy.net` untuk aktivasi *License Key* secara instan tanpa ribet.

### 2. 📝 Sistem Penerimaan Murid Baru (SPMB)
- Panel Pendaftaran Mandiri untuk calon siswa.
- Manajemen Status Pendaftar (Pending, Diterima, Ditolak).
- Verifikasi Dokumen & Konversi pendaftar yang lulus menjadi Siswa Aktif dengan satu klik.

### 3. 👥 Manajemen Data Siswa & Pegawai Terlengkap
- **Database Siswa Terpadu:** Sistem pencarian *real-time*, filter by kelas/rombel, dan profil detail siswa mencakup biodata, data periodik, afirmasi, hingga riwayat masuk/keluar.
- **Export & Import (Excel):** Fitur ekspor dan impor data massal untuk Siswa dan Pegawai secara mudah dan cepat.
- **ID Card Digital:** Kemampuan mencetak Kartu Tanda Pelajar lengkap dengan Barcode/QR-Code dengan desain elegan.
- **Manajemen Staf & Pegawai:** Pendataan Guru & Tenaga Kependidikan dengan gelar akademik yang ditampilkan otomatis.
- **Role-Based Access Control (RBAC):** Hak akses berjenjang yang ketat. Role *Superadmin* dikunci dan dilindungi secara sistem untuk stabilitas keamanan tertinggi.
- **Pengajuan Perubahan Data:** Fitur interaktif bagi pengguna untuk me-request perubahan data yang kemudian di-review oleh Admin.

### 4. 📅 Akademik & Operasional
- **Presensi Digital (Absensi):** Rekap kehadiran siswa harian dan absensi bidang studi dengan pelaporan yang terstruktur.
- **Jadwal Pelajaran:** Tata kelola mata pelajaran harian yang ringkas dan proporsional.
- **Kalender Akademik:** Penjadwalan kegiatan sekolah, hari libur, dan event penting.
- **Manajemen Kelas/Rombel:** Pemetaan siswa ke dalam rombongan belajar secara otomatis maupun manual.
- **Kegiatan Ekstrakurikuler:** Pendataan kegiatan luar jam sekolah (Bidang Ekskul) dan partisipasi aktif siswa.

### 5. 📢 Mading Digital & Publikasi
- **Pengumuman Resmi (Warta Sekolah):** Panel *broadcast* pengumuman untuk seluruh warga sekolah, yang langsung tampil interaktif di halaman depan Dashboard Pegawai.
- **Blog Sekolah:** Platform *Blogging* internal untuk mempublikasikan karya tulis, berita, maupun prestasi sekolah dengan penulis yang dinamis (menampilkan nama lengkap + gelar).
- **Galeri Foto:** Penyimpanan dokumentasi dan memori kegiatan sekolah.
- **SEO Friendly:** Meta tags otomatis menyesuaikan nama sekolah dan judul halaman untuk optimasi mesin pencari.

### 6. ⚙️ Kemudahan Tambahan (Utility)
- **Tautan Cepat (Quick Links):** Kumpulkan URL layanan penting seperti Dapodik, e-Rapor, BOS, dll dalam satu halaman yang mudah diakses *staff*.
- **Pilihan Tema UI Dinamis:** Terdapat 4 pilihan Tema (termasuk Tema *Modern* dan Tema *Cheerful* pastel) yang bisa diganti kapan saja oleh Admin langsung dari menu Pengaturan.
- **Live Clock:** Fitur penunjuk jam *real-time* dengan estetika tinggi di panel admin.
- **Pengaturan Aplikasi Ekstensif:** Kustomisasi Logo Sekolah, Nama Lembaga, Data Kontak, tanpa perlu menyentuh *coding*.

---

## 💻 Kebutuhan Sistem
- **Sistem Operasi:** Windows / Linux / macOS
- **Engine:** Node.js versi 18 atau lebih baru.
- **Database:** MySQL / MariaDB (Direkomendasikan menggunakan XAMPP atau Laragon).
- Akses Internet (Hanya saat proses pengecekan Lisensi / Aktivasi awal).

---

## 🚀 Panduan Instalasi & Menjalankan Aplikasi

1. **Clone & Install Dependensi**
   ```bash
   git clone https://github.com/syahmuhamadrizky/SekolahV2_Releases.git
   cd SekolahV2_Releases
   npm install --production
   ```

2. **Jalankan Aplikasi (Mode Produksi / VPS / cPanel)**
   ```bash
   node dist/server.cjs
   # Atau menggunakan PM2 untuk VPS:
   pm2 start dist/server.cjs --name "dapoy-schools"
   ```

---

## 🔑 Panduan Aktivasi Aplikasi

Ketika Dapoy Schools pertama kali dihidupkan, aplikasi akan masuk ke Mode Uji Coba (*Free Trial*).

**Cara Mengaktifkan Lisensi Penuh:**
1. Ketika masa uji coba habis (atau jika Anda ingin langsung aktivasi), layar akan otomatis terkunci.
2. Hubungi Admin (tombol WhatsApp tersedia di layar Lock Screen).
3. Anda akan diberikan *License Key* (contoh: `DSC-ABCDE-12345`).
4. Masukkan kunci tersebut di formulir aktivasi.
5. Selesai! Aplikasi akan terhubung ke Dapoy Hub, mencatat Hardware ID Anda, dan terbuka secara permanen.

---
**Hak Cipta © 2026 SMR** - [Dapoy.net](https://dapoy.net)
*Dapoy Schools - Transformasi Digital Pendidikan yang Sesungguhnya.*
